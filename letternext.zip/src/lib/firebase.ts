import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
  Auth,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  orderBy,
  Firestore,
} from 'firebase/firestore';
import { sanitizeForFirestore } from './sanitizer';
import { LetterRecord, ChatTurn } from '../types';

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export function getFirebaseConfig() {
  return {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
    appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
  };
}

export function initFirebase(): { app: FirebaseApp | null; auth: Auth | null; db: Firestore | null } {
  if (appInstance && authInstance && dbInstance) {
    return { app: appInstance, auth: authInstance, db: dbInstance };
  }

  const config = getFirebaseConfig();

  if (!config.apiKey || !config.projectId) {
    return { app: null, auth: null, db: null };
  }

  try {
    if (getApps().length > 0) {
      appInstance = getApp();
    } else {
      appInstance = initializeApp(config);
    }
    authInstance = getAuth(appInstance);
    dbInstance = getFirestore(appInstance);
    return { app: appInstance, auth: authInstance, db: dbInstance };
  } catch (err) {
    console.warn('Firebase initialization warning:', err);
    return { app: null, auth: null, db: null };
  }
}

export async function signInWithGoogle(): Promise<User> {
  const { auth, db } = initFirebase();
  if (!auth) {
    throw new Error('Firebase authentication is not initialized. Please verify configuration.');
  }
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;

  // Persist user profile under users/{uid}
  if (db && user) {
    try {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(
        userRef,
        sanitizeForFirestore({
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || '',
          photoURL: user.photoURL || '',
          lastLoginAt: new Date().toISOString(),
        }),
        { merge: true }
      );
    } catch (e) {
      console.warn('Could not update user record:', e);
    }
  }

  return user;
}

export async function logOut(): Promise<void> {
  const { auth } = initFirebase();
  if (auth) {
    await signOut(auth);
  }
}

export function onAuthChange(callback: (user: User | null) => void): () => void {
  const { auth } = initFirebase();
  if (!auth) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(auth, callback);
}

export async function saveLetterRecord(userId: string, record: LetterRecord): Promise<void> {
  const { auth, db } = initFirebase();
  // Derive authenticated UID from Firebase Auth to guarantee alignment with request.auth.uid
  const currentUid = auth?.currentUser?.uid || userId;

  if (!db || !currentUid) {
    console.warn('Database or authenticated user ID not available, saving to localStorage backup');
    try {
      const stored = localStorage.getItem(`letternext_local_${userId}`) || '[]';
      const letters: LetterRecord[] = JSON.parse(stored);
      const filtered = letters.filter((l) => l.id !== record.id);
      filtered.unshift(record);
      localStorage.setItem(`letternext_local_${userId}`, JSON.stringify(filtered));
    } catch (e) {
      console.error('LocalStorage save error:', e);
    }
    return;
  }

  const cleanPayload = sanitizeForFirestore({
    id: record.id,
    rawText: record.rawText,
    title: record.title,
    createdAt: record.createdAt,
    actionCard: record.actionCard,
    completedChecklist: record.completedChecklist || [],
  });

  // Always mirror locally so user data is never lost
  try {
    const stored = localStorage.getItem(`letternext_local_${currentUid}`) || '[]';
    const letters: LetterRecord[] = JSON.parse(stored);
    const filtered = letters.filter((l) => l.id !== record.id);
    filtered.unshift(record);
    localStorage.setItem(`letternext_local_${currentUid}`, JSON.stringify(filtered));
  } catch (localErr) {
    console.warn('Local storage mirror notice:', localErr);
  }

  // Exact Firestore path: users/{uid}/letters/{letterId}
  const letterRef = doc(db, 'users', currentUid, 'letters', record.id);
  await setDoc(letterRef, cleanPayload, { merge: true });
}

export async function loadUserLetters(userId: string): Promise<LetterRecord[]> {
  const { auth, db } = initFirebase();
  const currentUid = auth?.currentUser?.uid || userId;

  if (!db || !currentUid) {
    try {
      const stored = localStorage.getItem(`letternext_local_${userId}`) || '[]';
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }

  try {
    // Exact Firestore collection path: users/{uid}/letters
    const lettersRef = collection(db, 'users', currentUid, 'letters');
    const q = query(lettersRef, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const records: LetterRecord[] = [];
    snapshot.forEach((docSnap) => {
      records.push(docSnap.data() as LetterRecord);
    });
    return records;
  } catch (err) {
    console.warn('Firestore load notice, falling back to local storage cache:', err);
    try {
      const stored = localStorage.getItem(`letternext_local_${currentUid}`) || '[]';
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }
}

export async function saveChatTurn(
  userId: string,
  letterId: string,
  turn: ChatTurn
): Promise<void> {
  const { auth, db } = initFirebase();
  const currentUid = auth?.currentUser?.uid || userId;
  if (!db || !currentUid || !letterId) return;

  const cleanPayload = sanitizeForFirestore(turn);
  // Exact Firestore path: users/{uid}/letters/{letterId}/turns/{turnId}
  const turnRef = doc(db, 'users', currentUid, 'letters', letterId, 'turns', turn.id);
  await setDoc(turnRef, cleanPayload, { merge: true });
}

export async function loadChatTurns(userId: string, letterId: string): Promise<ChatTurn[]> {
  const { auth, db } = initFirebase();
  const currentUid = auth?.currentUser?.uid || userId;
  if (!db || !currentUid || !letterId) return [];

  try {
    // Exact Firestore collection path: users/{uid}/letters/{letterId}/turns
    const turnsRef = collection(db, 'users', currentUid, 'letters', letterId, 'turns');
    const q = query(turnsRef, orderBy('timestamp', 'asc'));
    const snapshot = await getDocs(q);
    const turns: ChatTurn[] = [];
    snapshot.forEach((d) => turns.push(d.data() as ChatTurn));
    return turns;
  } catch (e) {
    console.warn('Could not load chat turns from Firestore:', e);
    return [];
  }
}
