export type RiskLevel = 'act_now' | 'prepare' | 'wait' | 'possible_phishing';
export type LetterType = 'insurance_tpa' | 'bank_kyc' | 'tax_authority' | 'scholarship_exam' | 'utility_legal' | 'other';

export interface ActionCard {
  title: string;
  letter_type: LetterType;
  risk_level: RiskLevel;
  deadline_text: string;
  deadline_iso: string; // ISO date string e.g. '2026-09-08' or empty
  summary: string;
  missing_documents: string[];
  next_actions: string[];
  official_channel: string;
  draft_reply: string;
  caution: string;
}

export interface LetterRecord {
  id: string;
  rawText: string;
  title: string;
  createdAt: string;
  actionCard: ActionCard;
  completedChecklist: string[];
}

export interface ChatTurn {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface SampleLetter {
  id: string;
  label: string;
  tag: string;
  title: string;
  text: string;
}
