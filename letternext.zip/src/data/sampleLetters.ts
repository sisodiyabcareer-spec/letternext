export interface SampleLetter {
  id: string;
  name: string;
  badge: string;
  description: string;
  notes: string;
  text: string;
}

export const SAMPLE_LETTERS: SampleLetter[] = [
  {
    id: 'tpa_denial',
    name: 'TPA Cashless Denial',
    badge: 'Health Insurance',
    description: 'Hospital desk denial query citing clause 4.2 with a strict 48-hour deadline.',
    notes: 'Patient was admitted for acute abdominal pain. First policy taken 4 years ago with Star Health. Have hospital bill receipts and current discharge notes.',
    text: `MED-HEALTH TPA SERVICES LTD.
(IRDAI Regn No: TPA/018/2019)
Level 4, Care Towers, Healthcare Avenue, Tech Zone

Date: 02-Sep-2026
CLAIM ID: MH-2026-994821
POLICY NO: 2819-4402-9912-00
INSURED NAME: Alex R. Sharma
HOSPITAL: St. Jude Specialty Care, Ward 4B

SUBJECT: DENIAL OF CASHLESS PRE-AUTHORIZATION REQUEST - DEFICIENCY QUERY 4.2

Dear Insured / Hospital TPA Desk,

This has reference to the cashless pre-authorization request received on 01-Sep-2026 for the proposed admission of Alex R. Sharma for Laparoscopic Cholecystectomy under Policy Clause 4.2 (Pre-Existing Disease Moratorium).

Upon initial medical scrutinization of the preliminary admission sheet and duration of complaints, the Medical Board observes that the patient reports intermittent symptoms dating prior to the current policy inception date.

CONSEQUENTLY, CASHLESS AUTHORIZATION STANDS REJECTED AT THIS STAGE UNDER CODE DEF-402.

REQUIREMENTS FOR RECONSIDERATION / REIMBURSEMENT:
In order to review this decision or convert to reimbursement processing, the following documentary evidence must be submitted within 48 HOURS (Deadline: 04-Sep-2026, 17:00 IST):
1. Complete first consultation paper and treating physician prescription certifying exact symptom onset.
2. Indoor Case Papers (ICP) with hourly vitals, nursing notes, and surgical anaesthesia record.
3. Continuous renewal certificate and policy schedule for the preceding 3 consecutive years.
4. Treating surgeon certificate stating whether condition is congenital, alcoholic, or pre-existing.
5. All diagnostic ultrasound (USG) reports and baseline blood pathology films.

IMPORTANT INSTRUCTION:
Hospital desk must NOT proceed with cashless billing without written approval. Do not reply to unverified email domains. Submit all verified physical scans directly via the hospital TPA portal (https://portal.medhealthtpa.co.in/provider-desk) or at the hospital billing desk. 

Medical Claims Officer,
Pre-Authorization Desk, Med-Health TPA`,
  },
  {
    id: 'kyc_freeze',
    name: 'Bank KYC Freeze Warning',
    badge: 'Banking & Finance',
    description: 'Account debit freeze warning with high fraud caution and branch submission mandate.',
    notes: 'Received SMS from shortcode saying account will freeze. No online link was clicked. Have original passport, voter ID, and utility bill.',
    text: `APEX NATIONAL COMMERCIAL BANK
Operations Department, Retail Banking Division
Central Processing Hub, Financial District

Ref: ANB/OPS/KYC-FREEZE/2026-0811
Date: August 30, 2026

URGENT NOTICE: REGULATORY RE-KYC NON-COMPLIANCE - IMPENDING ACCOUNT SUSPENSION

Account Number: XXXX-XXXX-8921
Primary Account Holder: Jordan M. Taylor
Branch: Metro Core Branch (IFSC: ANB0001844)

Dear Valued Customer,

As per Reserve Bank / Statutory Anti-Money Laundering (AML) directives, all classified high/medium risk savings accounts are required to complete mandatory periodic Re-KYC verification.

Despite our prior SMS alerts, our compliance records reflect that your account documentation has not been refreshed for the triennial cycle ending August 2026.

TAKE NOTE: A TEMPORARY DEBIT RESTRICTION (OUTGOING TRANSACTION FREEZE) WILL BE ENFORCED EFFECTIVE SEPTEMBER 10, 2026 (10-Sep-2026) UNLESS SATISFACTORY RE-KYC IS RECORDED.

REQUIRED DOCUMENTS TO RESTORE FULL PRIVILEGES:
1. Self-attested copy of any Officially Valid Document (OVD): Passport, Driving License, Voter Identity Card, or Proof of Possession of Aadhaar (masked).
2. Permanent Account Number (PAN) Card copy or Form 60 declaration with latest passport-sized photograph.
3. Current residential address proof (Utility bill dated within past 60 days) if current address differs from bank records.
4. Duly filled and signed Customer Re-KYC Update Declaration Form (Form KYC-R2).

SECURITY ALERT & OFFICIAL SUBMISSION CHANNEL:
Do NOT click any SMS links, shortened bit.ly URLs, or share OTPs over phone calls requesting KYC updates. The Bank never sends APK files or external payment links for verification. 
To complete Re-KYC safely:
- Visit your registered home branch in person with original OVDs for in-person verification (IPV); OR
- Login securely to the bank's official internet banking portal (https://netbanking.apexbank.com) and navigate to Services > Profile > Re-KYC Submission.

Chief Compliance Manager,
Retail Risk & Compliance, Apex National Bank`,
  },
  {
    id: 'scholarship_circular',
    name: 'National Scholarship Circular',
    badge: 'Education & Grants',
    description: 'Post-graduate grant verification circular requiring attested Annexures and college seal.',
    notes: 'Awarded PG Merit Fellowship last semester. Need to know what college stamps are needed before Dean office closes.',
    text: `NATIONAL HIGHER EDUCATION COUNCIL & SCHOLARSHIP BOARD
Department of Higher Grants, Shastri Bhawan, New Delhi
Circular No: NHEC/SCH/PG-MERIT/2026/CIRC-114

Date: 01 September 2026

CIRCULAR: MANDATORY PHYSICAL DOSSIER VERIFICATION FOR PG RESEARCH SCHOLARS (CYCLE-IV)

To:
The Registrar / Dean of Student Welfare / Head of Institutions,
All Eligible Beneficiaries under National Post-Graduate Excellence Scheme (2025-2026).

Attention of all provisionally shortlisted scholars is invited to the disbursement guidelines for the current fiscal session. Multiple disbursement accounts have failed DBT (Direct Benefit Transfer) validation due to mismatches in Aadhaar-seeded bank ledgers and incomplete institutional credentials.

ALL PROVISIONALLY SELECTED SCHOLARS MUST COMPLETE DEFICIENCY COMPLIANCE ON OR BEFORE SEPTEMBER 18, 2026 (18-Sep-2026).

MANDATORY DOCUMENTS & ANNEXURES PACK:
1. Annexure-IV (Academic Progress & 75% Minimum Attendance Report) certified and signed by the Department Head.
2. Annexure-VII (Income Affidavit sworn before a First Class Judicial Magistrate or Notary Public) stating annual household income below INR 8,00,000.
3. Original Fee Receipt of Current Academic Semester along with Bonafide Student Certificate bearing institutional seal.
4. Mandate Form (Form-9B) endorsed with Bank Branch Manager signature and stamp confirming NPCI Aadhaar seeding status.
5. Previous degree final marksheet and Council Eligibility Certificate.

SUBMISSION PROCEDURE:
The institution nodal officer must upload scanned, counter-signed PDF dossiers to the Council Higher Grants Portal (https://grants.nhec.gov.in/scholar-portal). Incomplete submissions or dossiers without institutional round seal will lead to automatic forfeiture of fellowship stipends for Q3 and Q4.

Joint Secretary (Grants & Fellowships),
National Higher Education Council`,
  },
];
