import { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  FileText,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Copy,
  Check,
  Send,
  ShieldAlert,
  ArrowRight,
  LogOut,
  Sparkles,
  History,
  PlusCircle,
  ExternalLink,
  ShieldCheck,
  HelpCircle,
  Info,
} from 'lucide-react';
import {
  signInWithGoogle,
  logOut,
  onAuthChange,
  saveLetterRecord,
  loadUserLetters,
  saveChatTurn,
  loadChatTurns,
} from './lib/firebase';
import { ActionCard, LetterRecord, ChatTurn, SampleLetter, RiskLevel } from './types';

const SAMPLE_LETTERS: SampleLetter[] = [
  {
    id: 'sample-tpa',
    label: 'Sample 1: TPA Denial',
    tag: 'Insurance',
    title: 'Med-Health TPA Cashless Denial',
    text: `MED-HEALTH TPA SERVICES LTD.
HEALTH INSURANCE DIVISION, CLAIM ID: MH-2026-994821
POLICY NO: 2811/4910283/01/000

Dear Insured / Hospital Authority,
RE: PRE-AUTHORIZATION REQUEST FOR CASHLESS HOSPITALIZATION - DENIAL UNDER CLAUSE 4.2

With reference to the pre-authorization cashless request submitted on 02-Sep-2026 for patient Aditi Sharma admitted at Apollo Care Hospital, please be informed that after preliminary clinical scrutiny, the request for cashless access cannot be approved at this stage due to the following deficiencies:
- Clause 4.2: First consultation paper establishing the duration and progression of symptoms prior to insurance inception is missing.
- Pre-existing condition duration not certified by primary treating physician.

REQUIRED DOCUMENTS TO REOPEN PRE-AUTH REVIEW:
1. Complete Indoor Case Papers (ICP) with hourly nursing vitals and admission notes.
2. First consultation sheet dated prior to current hospitalization.
3. Treating physician certificate clarifying exact timeline of initial diagnosis.
4. Investigation reports including baseline USG and serum biochemical markers.
5. Previous 3 continuous policy renewal certificates.

SUBMISSION DEADLINE:
The above must be submitted within 48 HOURS of this notice (no later than 07-Sep-2026 at 17:00 IST) through the official hospital portal or directly at the hospital TPA desk. If unfulfilled, the claim will be treated as closed under cashless and must be filed as a post-discharge reimbursement claim.`,
  },
  {
    id: 'sample-kyc',
    label: 'Sample 2: Bank KYC Freeze',
    tag: 'Banking / Risk',
    title: 'Priority Bank KYC Account Suspension',
    text: `PRIORITY CITIZEN BANK
NOTICE OF MANDATORY PERIODIC KYC RE-AUTHENTICATION
ACCOUNT NUMBER: XXXXXXXX4019
DATE: 01-Sep-2026

Dear Valued Customer,
In compliance with central regulatory directives on customer due diligence, our records indicate that periodic KYC updation for your savings account is pending past the statutory due date.

CONSEQUENCE OF NON-COMPLIANCE:
If valid identity and address credentials are not resubmitted within 7 days (by 12-Sep-2026), your account will face temporary debit restrictions. You will not be able to execute UPI transfers, ATM withdrawals, or netbanking NEFT/RTGS outward transactions.

MANDATORY DOCUMENTS REQUIRED:
1. One Officially Valid Document (OVD): Physical copy of Passport, Voter Card, Driving License, or masked Aadhaar.
2. Recent passport-sized photograph (taken within 3 months).
3. Self-attested PAN card or Form 60 declaration.
4. Proof of latest communication address if different from OVD.

SAFETY ADVISORY:
Priority Citizen Bank NEVER sends SMS or WhatsApp links asking you to upload documents or enter OTPs. Do not click on bit.ly or third-party links. Please submit documents in person at your home branch or log in to our official domain www.prioritycitizenbank.example.com directly.`,
  },
  {
    id: 'sample-scholarship',
    label: 'Sample 3: Scholarship Circular',
    tag: 'Education',
    title: 'National Merit Scholarship Deficiency',
    text: `DIRECTORATE OF HIGHER EDUCATION & WELFARE
NATIONAL MERIT POST-MATRIC SCHOLARSHIP SCHEME (2026-2027)
APPLICATION ID: NMS-UG-2026-88319

MEMORANDUM: NOTICE REGARDING DEFICIENCY IN UPLOADED DOSSIER

Applicant: Rahul Verma
College / Institute: Government Engineering College, Sector 12

Upon initial administrative verification of your application for scholarship disbursement, the following discrepancies were flagged by the scrutinizing officer:
1. Income certificate issued by competent revenue authority is dated prior to the current financial year.
2. College fee receipt does not bear the official seal and countersignature of the Dean / Registrar.
3. Annexure-IV (Hostel Accommodation Certificate) was uploaded in an unreadable resolution.

ACTION MANDATED:
You are directed to rectify the above deficiencies by uploading clean, self-attested scanned PDF documents onto the state portal (scholarships.state.gov.example) and submitting one physical dossier set to your college scholarship nodal officer.

LAST DATE FOR RESUBMISSION:
18-Sep-2026 at 23:59 IST. Failure to rectify by this date will lead to permanent cancellation of your scholarship allotment for the academic term.`,
  },
];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [letterText, setLetterText] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [actionCard, setActionCard] = useState<ActionCard | null>(null);
  const [currentLetterId, setCurrentLetterId] = useState<string | null>(null);
  const [completedItems, setCompletedItems] = useState<string[]>([]);
  const [chatTurns, setChatTurns] = useState<ChatTurn[]>([]);
  const [chatInput, setChatInput] = useState<string>('');
  const [chatLoading, setChatLoading] = useState<boolean>(false);
  const [historyLetters, setHistoryLetters] = useState<LetterRecord[]>([]);
  const [copiedDraft, setCopiedDraft] = useState<boolean>(false);
  const [copiedChecklist, setCopiedChecklist] = useState<boolean>(false);

  // Initialize Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthChange((currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
      if (currentUser) {
        refreshHistory(currentUser.uid);
      }
    });
    return () => unsubscribe();
  }, []);

  const refreshHistory = async (uid: string) => {
    try {
      const letters = await loadUserLetters(uid);
      setHistoryLetters(letters);
    } catch (e) {
      console.warn('Failed to load letter history:', e);
    }
  };

  const handleSignIn = async () => {
    setErrorBanner(null);
    try {
      await signInWithGoogle();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to sign in with Google';
      setErrorBanner(msg);
    }
  };

  const handleSignOut = async () => {
    await logOut();
    setActionCard(null);
    setCurrentLetterId(null);
    setChatTurns([]);
  };

  const handleSelectSample = (sample: SampleLetter) => {
    setLetterText(sample.text);
    setErrorBanner(null);
  };

  const handleAnalyze = async () => {
    if (!letterText.trim()) {
      setErrorBanner('Please paste an official letter or select one of the sample letters.');
      return;
    }

    setIsAnalyzing(true);
    setErrorBanner(null);
    setActionCard(null);
    setCompletedItems([]);
    setChatTurns([]);

    try {
      const response = await fetch('/api/analyze-letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText: letterText }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || errData.details || `Server responded with status ${response.status}`);
      }

      const data = await response.json();
      if (!data.success || !data.actionCard) {
        throw new Error('Analysis completed but did not produce a structured action card.');
      }

      const card: ActionCard = data.actionCard;
      const letterId = `letter_${Date.now()}`;
      setActionCard(card);
      setCurrentLetterId(letterId);

      // Persist to user's private collection if signed in
      if (user) {
        const record: LetterRecord = {
          id: letterId,
          rawText: letterText,
          title: card.title || 'Official Letter Analysis',
          createdAt: new Date().toISOString(),
          actionCard: card,
          completedChecklist: [],
        };
        await saveLetterRecord(user.uid, record);
        refreshHistory(user.uid);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to analyze letter. Please check connection.';
      setErrorBanner(msg);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toggleChecklistItem = async (item: string) => {
    const updated = completedItems.includes(item)
      ? completedItems.filter((i) => i !== item)
      : [...completedItems, item];

    setCompletedItems(updated);

    if (user && currentLetterId && actionCard) {
      const record: LetterRecord = {
        id: currentLetterId,
        rawText: letterText,
        title: actionCard.title,
        createdAt: new Date().toISOString(),
        actionCard,
        completedChecklist: updated,
      };
      await saveLetterRecord(user.uid, record);
    }
  };

  const handleCopyDraft = () => {
    if (!actionCard?.draft_reply) return;
    navigator.clipboard.writeText(actionCard.draft_reply);
    setCopiedDraft(true);
    setTimeout(() => setCopiedDraft(false), 2000);
  };

  const handleCopyChecklist = () => {
    if (!actionCard?.missing_documents) return;
    const text = actionCard.missing_documents
      .map((doc, idx) => `[${completedItems.includes(doc) ? 'X' : ' '}] ${idx + 1}. ${doc}`)
      .join('\n');
    navigator.clipboard.writeText(`MISSING DOCUMENTS CHECKLIST:\n${text}`);
    setCopiedChecklist(true);
    setTimeout(() => setCopiedChecklist(false), 2000);
  };

  const handleSendChat = async () => {
    if (!chatInput.trim() || !actionCard) return;

    const userMessage = chatInput.trim();
    setChatInput('');
    setChatLoading(true);

    const userTurn: ChatTurn = {
      id: `turn_${Date.now()}_u`,
      role: 'user',
      content: userMessage,
      timestamp: new Date().toISOString(),
    };

    const newTurns = [...chatTurns, userTurn];
    setChatTurns(newTurns);

    if (user && currentLetterId) {
      await saveChatTurn(user.uid, currentLetterId, userTurn);
    }

    try {
      const res = await fetch('/api/chat-letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          letterContext: `Title: ${actionCard.title}\nSummary: ${actionCard.summary}\nRaw Letter: ${letterText}`,
          history: newTurns.map((t) => ({ role: t.role, content: t.content })),
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to get answer from assistant');
      }

      const data = await res.json();
      const assistantTurn: ChatTurn = {
        id: `turn_${Date.now()}_a`,
        role: 'assistant',
        content: data.reply || 'Here is the requested guidance.',
        timestamp: new Date().toISOString(),
      };

      setChatTurns([...newTurns, assistantTurn]);
      if (user && currentLetterId) {
        await saveChatTurn(user.uid, currentLetterId, assistantTurn);
      }
    } catch (e: unknown) {
      const errMsg = e instanceof Error ? e.message : 'Error sending follow-up';
      setErrorBanner(errMsg);
    } finally {
      setChatLoading(false);
    }
  };

  const handleLoadHistoryLetter = async (rec: LetterRecord) => {
    setLetterText(rec.rawText);
    setActionCard(rec.actionCard);
    setCurrentLetterId(rec.id);
    setCompletedItems(rec.completedChecklist || []);
    setErrorBanner(null);

    if (user) {
      const turns = await loadChatTurns(user.uid, rec.id);
      setChatTurns(turns);
    }
  };

  const handleNewAnalysis = () => {
    setLetterText('');
    setActionCard(null);
    setCurrentLetterId(null);
    setCompletedItems([]);
    setChatTurns([]);
    setErrorBanner(null);
  };

  // Helper to test if deadline is within 7 days
  const isUrgentDeadline = (deadlineIso: string, deadlineText: string): boolean => {
    if (deadlineText.toLowerCase().includes('48 hour') || deadlineText.toLowerCase().includes('24 hour') || deadlineText.toLowerCase().includes('today') || deadlineText.toLowerCase().includes('tomorrow')) {
      return true;
    }
    if (!deadlineIso) return false;
    try {
      const target = new Date(deadlineIso);
      const now = new Date();
      const diffMs = target.getTime() - now.getTime();
      const diffDays = diffMs / (1000 * 60 * 60 * 24);
      return diffDays >= -1 && diffDays <= 7;
    } catch {
      return false;
    }
  };

  const renderRiskBadge = (risk: RiskLevel) => {
    switch (risk) {
      case 'act_now':
        return (
          <span id="risk-badge-act-now" className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-950/80 border border-rose-500/50 text-rose-300">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            Urgent Action Mandated
          </span>
        );
      case 'possible_phishing':
        return (
          <span id="risk-badge-phishing" className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-950/80 border border-amber-500/50 text-amber-300">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            Possible Scam / Phishing
          </span>
        );
      case 'prepare':
        return (
          <span id="risk-badge-prepare" className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-950/80 border border-indigo-500/50 text-indigo-300">
            <Info className="w-3.5 h-3.5 text-indigo-400" />
            Standard Due Date
          </span>
        );
      case 'wait':
      default:
        return (
          <span id="risk-badge-wait" className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-neutral-800 border border-neutral-700 text-neutral-300">
            <HelpCircle className="w-3.5 h-3.5 text-neutral-400" />
            Advisory Notice
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-950 text-neutral-100 selection:bg-amber-500/30 selection:text-amber-200">
      {/* App Navigation Bar */}
      <header id="app-header" className="sticky top-0 z-30 border-b border-neutral-800/80 bg-neutral-950/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-sm shadow-amber-500/10">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display text-lg font-bold tracking-tight text-neutral-100">LetterNext</span>
                <span className="text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
                  Citizen Triage
                </span>
              </div>
              <p className="text-xs text-neutral-400 hidden sm:block">
                Official Letter In. Deadline and Document Pack Out.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {authLoading ? (
              <div className="h-8 w-24 bg-neutral-800 animate-pulse rounded-lg" />
            ) : user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'User'}
                      className="w-6 h-6 rounded-full border border-neutral-700"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-bold">
                      {(user.displayName || user.email || 'U')[0].toUpperCase()}
                    </div>
                  )}
                  <span className="text-xs text-neutral-300 font-medium max-w-[120px] truncate hidden sm:inline">
                    {user.displayName || user.email}
                  </span>
                </div>
                <button
                  id="sign-out-button"
                  onClick={handleSignOut}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900 border border-transparent hover:border-neutral-800 transition-colors flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Sign Out</span>
                </button>
              </div>
            ) : (
              <button
                id="sign-in-button"
                onClick={handleSignIn}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-neutral-950 flex items-center gap-2 shadow-sm transition-all"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Sign In with Google</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {/* Error Banner */}
        {errorBanner && (
          <div
            id="error-banner"
            className="mb-6 p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-sm flex items-start gap-3"
          >
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold text-rose-300">Action Required</p>
              <p className="text-xs text-rose-300/90 mt-0.5">{errorBanner}</p>
            </div>
            <button
              onClick={() => setErrorBanner(null)}
              className="text-xs text-rose-400 hover:text-rose-200 underline"
            >
              Dismiss
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left / Input Section */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* Citizen Pitch & Sample Switcher */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    Triage Scary Official Correspondence
                  </h2>
                  <p className="text-xs text-neutral-400 mt-1">
                    Paste notices from insurance TPAs, banks, tax queries, or colleges. LetterNext isolates deadlines, missing documents, and safe next steps.
                  </p>
                </div>
              </div>

              {/* Sample Buttons for Instant Review */}
              <div className="flex flex-col gap-2 pt-2 border-t border-neutral-800">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-neutral-500">
                  Quick Judge / Citizen Demos:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {SAMPLE_LETTERS.map((s) => (
                    <button
                      key={s.id}
                      id={`sample-button-${s.id}`}
                      onClick={() => handleSelectSample(s)}
                      className="p-2.5 text-left rounded-xl bg-neutral-800/60 hover:bg-neutral-800 border border-neutral-700/60 hover:border-amber-500/50 transition-all flex flex-col justify-between group"
                    >
                      <span className="text-xs font-medium text-neutral-200 group-hover:text-amber-300 line-clamp-1">
                        {s.label}
                      </span>
                      <span className="text-[10px] text-neutral-400 mt-1">{s.tag}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Letter Input Card */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <label htmlFor="letter-textarea" className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Letter Text / Pasted Notice
                </label>
                <span className="text-xs font-mono text-neutral-500">
                  {letterText.length} / 20,000 chars
                </span>
              </div>

              <textarea
                id="letter-textarea"
                rows={12}
                value={letterText}
                onChange={(e) => setLetterText(e.target.value.slice(0, 20000))}
                placeholder="Paste the full text of the letter, circular, or query received (e.g. from Med-Health TPA, bank, or scholarship portal)..."
                className="w-full p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 focus:border-amber-500/70 focus:ring-1 focus:ring-amber-500/70 text-sm text-neutral-200 placeholder:text-neutral-600 font-mono resize-none focus:outline-none leading-relaxed transition-all"
              />

              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  id="clear-letter-button"
                  onClick={handleNewAnalysis}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
                >
                  Clear Editor
                </button>

                <button
                  id="analyze-letter-button"
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || !letterText.trim()}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-neutral-800 text-neutral-950 disabled:text-neutral-500 font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 transition-all cursor-pointer disabled:cursor-not-allowed"
                >
                  {isAnalyzing ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                      <span>Extracting Facts & Deadlines...</span>
                    </>
                  ) : (
                    <>
                      <span>Analyze Letter Tonight</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* User History Sidebar (if signed in) */}
            {user && historyLetters.length > 0 && (
              <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <History className="w-4 h-4 text-neutral-400" />
                    <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                      Saved Letters ({historyLetters.length})
                    </span>
                  </div>
                  <button
                    onClick={handleNewAnalysis}
                    className="text-[11px] text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <PlusCircle className="w-3 h-3" />
                    New
                  </button>
                </div>

                <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-1">
                  {historyLetters.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleLoadHistoryLetter(item)}
                      className={`p-2.5 text-left rounded-xl border text-xs transition-all flex flex-col gap-1 ${
                        currentLetterId === item.id
                          ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                          : 'bg-neutral-950/60 border-neutral-800/60 text-neutral-300 hover:border-neutral-700'
                      }`}
                    >
                      <span className="font-medium truncate">{item.title}</span>
                      <div className="flex items-center justify-between text-[10px] text-neutral-500">
                        <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                        <span>{item.actionCard.letter_type}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right / Results & Action Card Section */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            {!actionCard && !isAnalyzing && (
              <div className="h-full min-h-[420px] rounded-2xl border border-dashed border-neutral-800 bg-neutral-900/20 p-8 flex flex-col items-center justify-center text-center">
                <div className="w-14 h-14 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-500 mb-4">
                  <FileText className="w-7 h-7" />
                </div>
                <h3 className="text-base font-semibold text-neutral-300">Ready to Triage Your Letter</h3>
                <p className="text-xs text-neutral-500 max-w-md mt-1.5 leading-relaxed">
                  Paste an official correspondence or select a sample notice on the left. LetterNext extracts strict deadlines, flags phishing links, creates missing-document checklists, and generates formal draft replies.
                </p>
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <button
                    onClick={() => handleSelectSample(SAMPLE_LETTERS[0])}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium bg-neutral-800 text-neutral-300 hover:bg-neutral-700 transition-colors"
                  >
                    Test TPA Sample
                  </button>
                  <button
                    onClick={() => handleSelectSample(SAMPLE_LETTERS[1])}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium bg-neutral-800 text-neutral-300 hover:bg-neutral-700 transition-colors"
                  >
                    Test Bank Sample
                  </button>
                </div>
              </div>
            )}

            {isAnalyzing && (
              <div className="min-h-[420px] rounded-2xl border border-neutral-800 bg-neutral-900/40 p-8 flex flex-col items-center justify-center text-center">
                <div className="w-12 h-12 rounded-full border-3 border-amber-500/20 border-t-amber-400 animate-spin mb-4" />
                <h3 className="text-sm font-semibold text-neutral-200">Deconstructing Bureaucratic Text...</h3>
                <p className="text-xs text-neutral-500 max-w-sm mt-1">
                  Parsing clauses, calculating deadlines, validating safe official channels, and preparing your response draft.
                </p>
              </div>
            )}

            {actionCard && !isAnalyzing && (
              <div id="action-card-container" className="flex flex-col gap-6">
                {/* Master Action Card */}
                <div className="p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex flex-col gap-6 shadow-xl">
                  {/* Card Header & Risk Level */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-neutral-800">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
                          {actionCard.letter_type.replace('_', ' ')}
                        </span>
                        {renderRiskBadge(actionCard.risk_level)}
                      </div>
                      <h2 id="action-card-title" className="text-lg font-bold text-neutral-100 font-display mt-1">
                        {actionCard.title}
                      </h2>
                    </div>

                    {/* Deadline Chip - Turns Bold Red if Urgent */}
                    <div
                      id="action-card-deadline"
                      className={`px-4 py-2.5 rounded-xl border flex items-center gap-2.5 self-start sm:self-auto ${
                        isUrgentDeadline(actionCard.deadline_iso, actionCard.deadline_text)
                          ? 'bg-rose-950/80 border-rose-500 text-rose-200 font-bold animate-pulse'
                          : 'bg-neutral-800/80 border-neutral-700 text-neutral-200'
                      }`}
                    >
                      <Clock className={`w-4 h-4 ${isUrgentDeadline(actionCard.deadline_iso, actionCard.deadline_text) ? 'text-rose-400' : 'text-neutral-400'}`} />
                      <div className="flex flex-col text-left">
                        <span className="text-[10px] uppercase tracking-wider text-neutral-400 font-normal">
                          Filing Deadline
                        </span>
                        <span className="text-xs font-semibold">{actionCard.deadline_text}</span>
                      </div>
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="flex flex-col gap-1.5">
                    <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                      Plain-English Summary
                    </span>
                    <p className="text-sm text-neutral-200 leading-relaxed">
                      {actionCard.summary}
                    </p>
                  </div>

                  {/* Missing Documents Pack */}
                  {actionCard.missing_documents && actionCard.missing_documents.length > 0 && (
                    <div id="missing-documents-pack" className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col gap-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-200">
                            Missing-Document Pack ({completedItems.length}/{actionCard.missing_documents.length} Secured)
                          </span>
                        </div>
                        <button
                          id="copy-checklist-button"
                          onClick={handleCopyChecklist}
                          className="px-2.5 py-1 rounded-lg text-xs font-medium text-neutral-400 hover:text-neutral-200 bg-neutral-900 border border-neutral-800 hover:border-neutral-700 flex items-center gap-1 transition-all"
                        >
                          {copiedChecklist ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedChecklist ? 'Copied' : 'Copy List'}</span>
                        </button>
                      </div>

                      <div className="flex flex-col gap-2 pt-1">
                        {actionCard.missing_documents.map((docName, idx) => {
                          const isDone = completedItems.includes(docName);
                          return (
                            <button
                              key={idx}
                              onClick={() => toggleChecklistItem(docName)}
                              className={`p-2.5 rounded-lg border text-left flex items-start gap-3 transition-all ${
                                isDone
                                  ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300 line-through opacity-80'
                                  : 'bg-neutral-900/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                              }`}
                            >
                              <div
                                className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center shrink-0 border ${
                                  isDone ? 'bg-emerald-500 border-emerald-400 text-neutral-950' : 'border-neutral-600 bg-neutral-800'
                                }`}
                              >
                                {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                              </div>
                              <span className="text-xs leading-relaxed">{docName}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Safe Next Actions */}
                  {actionCard.next_actions && actionCard.next_actions.length > 0 && (
                    <div className="flex flex-col gap-2">
                      <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                        Safe Next Actions (Tonight & Tomorrow)
                      </span>
                      <ol className="flex flex-col gap-2">
                        {actionCard.next_actions.map((act, idx) => (
                          <li
                            key={idx}
                            className="p-3 rounded-xl bg-neutral-950/50 border border-neutral-800/80 flex items-start gap-3 text-xs text-neutral-300"
                          >
                            <span className="w-5 h-5 rounded-full bg-amber-500/10 text-amber-400 font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="leading-relaxed">{act}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {/* Official Verified Channel */}
                  {actionCard.official_channel && (
                    <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-500/30 flex items-start gap-3 text-xs text-blue-200">
                      <ExternalLink className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-blue-300">Safe Official Submission Channel</span>
                        <p className="mt-0.5 text-blue-200/90 leading-relaxed">{actionCard.official_channel}</p>
                      </div>
                    </div>
                  )}

                  {/* Formal Draft Reply */}
                  {actionCard.draft_reply && (
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                          Draft Formal Reply
                        </span>
                        <button
                          id="copy-draft-button"
                          onClick={handleCopyDraft}
                          className="px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-500 hover:bg-amber-400 text-neutral-950 flex items-center gap-1.5 transition-all shadow-sm"
                        >
                          {copiedDraft ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedDraft ? 'Copied to Clipboard' : 'Copy Draft Reply'}</span>
                        </button>
                      </div>
                      <pre className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-300 font-mono whitespace-pre-wrap leading-relaxed">
                        {actionCard.draft_reply}
                      </pre>
                    </div>
                  )}

                  {/* Compliance & Safety Caution */}
                  {actionCard.caution && (
                    <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 text-[11px] text-neutral-400 flex items-start gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{actionCard.caution}</p>
                    </div>
                  )}
                </div>

                {/* Multi-turn Chat Follow-Up */}
                <div className="p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex flex-col gap-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
                      <Send className="w-4 h-4 text-amber-400" />
                      Follow-up Questions on this Letter
                    </h3>
                    <span className="text-[11px] text-neutral-500">
                      e.g. &quot;How do I get ICP?&quot; or &quot;Rewrite draft in simpler tone&quot;
                    </span>
                  </div>

                  {/* Chat Message History */}
                  <div className="flex flex-col gap-3 max-h-80 overflow-y-auto pr-1">
                    {chatTurns.length === 0 ? (
                      <p className="text-xs text-neutral-500 italic py-2">
                        Have questions about medical terms, bank clauses, or what to say to the desk clerk? Ask below.
                      </p>
                    ) : (
                      chatTurns.map((turn) => (
                        <div
                          key={turn.id}
                          className={`p-3.5 rounded-xl text-xs leading-relaxed max-w-[85%] ${
                            turn.role === 'user'
                              ? 'bg-amber-500/10 border border-amber-500/30 text-amber-100 self-end'
                              : 'bg-neutral-950 border border-neutral-800 text-neutral-200 self-start'
                          }`}
                        >
                          <span className="text-[10px] font-mono uppercase tracking-wider block text-neutral-500 mb-1">
                            {turn.role === 'user' ? 'You' : 'LetterNext Assistant'}
                          </span>
                          <div className="whitespace-pre-wrap">{turn.content}</div>
                        </div>
                      ))
                    )}

                    {chatLoading && (
                      <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-400 self-start flex items-center gap-2">
                        <div className="w-3 h-3 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                        <span>Formulating answer...</span>
                      </div>
                    )}
                  </div>

                  {/* Chat Input Bar */}
                  <div className="flex items-center gap-2 pt-2 border-t border-neutral-800">
                    <input
                      id="chat-input"
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendChat();
                        }
                      }}
                      placeholder="Ask a question about this letter..."
                      className="flex-1 p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 focus:border-amber-500/70 text-xs text-neutral-200 placeholder:text-neutral-600 focus:outline-none"
                    />
                    <button
                      id="send-chat-button"
                      onClick={handleSendChat}
                      disabled={chatLoading || !chatInput.trim()}
                      className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-neutral-800 text-neutral-950 disabled:text-neutral-500 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer disabled:cursor-not-allowed"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
